package com.extracrates.storage;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface CrateStorage {
    Optional<Instant> getCooldown(UUID playerId, String crateId);

    void setCooldown(UUID playerId, String crateId, Instant timestamp);

    void clearCooldown(UUID playerId, String crateId);

    int getKeyCount(UUID playerId, String crateId);

    boolean consumeKey(UUID playerId, String crateId);

    void addKey(UUID playerId, String crateId, int amount);

    void logOpen(UUID playerId, String crateId, String rewardId, String serverId, Instant timestamp);

    void logOpenStarted(UUID playerId, String crateId, String serverId, Instant timestamp);

    void recordDelivery(UUID playerId, String crateId, String rewardId, DeliveryStatus status, int attempt, Instant timestamp);

    boolean acquireLock(UUID playerId, String crateId);

    void releaseLock(UUID playerId, String crateId);

    List<CrateOpenEntry> getOpenHistory(UUID playerId, OpenHistoryFilter filter, int limit, int offset);

    Optional<PendingReward> getPendingReward(UUID playerId);

    void setPendingReward(UUID playerId, String crateId, String rewardId);

    void markRewardDelivered(UUID playerId, String crateId, String rewardId);

    void clearPlayerData(UUID playerId);

    void close();
}
